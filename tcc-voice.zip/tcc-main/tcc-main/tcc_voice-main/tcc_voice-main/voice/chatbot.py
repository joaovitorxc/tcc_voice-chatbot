from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "http://localhost:3000"}})
  # Permitir acesso do site (localhost)

@app.route('/somar', methods=['POST'])
def somar():
    dados = request.get_json()
    numero1 = float(dados.get('numero1', 0))
    numero2 = float(dados.get('numero2', 0))
    resultado = numero1 + numero2
    return jsonify({'resultado': resultado})

if __name__ == '__main__':
    app.run(debug=True)
