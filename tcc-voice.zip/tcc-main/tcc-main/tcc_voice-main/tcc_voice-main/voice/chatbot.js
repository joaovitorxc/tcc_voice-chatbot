fetch('http://localhost:5000/somar', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    numero1: 5,
    numero2: 3
  })
})
.then(response => response.json())
.then(data => {
  console.log('Resultado:', data.resultado);
})
.catch(error => {
  console.error('Erro na requisição:', error);
});
 